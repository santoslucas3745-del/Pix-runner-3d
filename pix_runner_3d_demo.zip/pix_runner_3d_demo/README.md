# Pix Runner 3D — demo segura

Protótipo jogável de corrida infinita em perspectiva pseudo-3D. Inclui pistas, obstáculos, moedas virtuais, pontuação, recorde local e tela de Pix demonstrativa.

## Testar
Abra `index.html` no navegador. Para publicar, envie o arquivo a um serviço de hospedagem estática (por exemplo, GitHub Pages).

## Importante
O botão Pix é apenas demonstrativo. Este projeto não cria cobranças nem recebe dinheiro real. Não há prêmios em dinheiro. Para uma solução de pagamento real, seriam necessários backend, provedor compatível, confirmação segura por webhook e avaliação jurídica da cobrança/premiação antes de lançar.
